ITACHI SUNSET CONTROL — PROYEK ANDROID AWAL

Ini proyek sumber Android native (Kotlin), bukan APK yang sudah dikompilasi.

Yang disertakan:
- Tampilan bertema senja.
- Tombol meminta izin berbagi layar melalui dialog resmi Android.
- Notifikasi sesi yang terlihat.
- Tombol untuk menghentikan sesi.
- Tidak mengirim layar ke internet dan tidak menerima perintah jarak jauh.

Yang BELUM disertakan:
- Koneksi antara dua perangkat.
- Kode sesi yang menghubungkan perangkat.
- Streaming layar ke HP pengendali.
- Kontrol sentuhan jarak jauh.

Untuk membuat APK, buka folder proyek ini di Android Studio, tunggu Gradle selesai,
lalu pilih Build > Build APK(s). APK debug biasanya ada di:
app/build/outputs/apk/debug/app-debug.apk

Persyaratan untuk kontrol jarak jauh sungguhan:
Perlu aplikasi pengendali dan pendamping, koneksi terenkripsi, persetujuan eksplisit
pada HP tujuan, serta pengujian. Kode acak saja tidak memberi akses.
