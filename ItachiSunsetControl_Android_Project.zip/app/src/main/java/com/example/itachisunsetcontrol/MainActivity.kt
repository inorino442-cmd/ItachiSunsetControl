package com.example.itachisunsetcontrol

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 4101
    private val notificationRequest = 4102
    private lateinit var status: TextView

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(Color.rgb(27, 17, 38))
        }

        val title = TextView(this).apply {
            text = "🌅 Itachi Sunset Control"
            textSize = 25f
            setTextColor(Color.rgb(255, 218, 170))
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(8))
        }
        val subtitle = TextView(this).apply {
            text = "Panel berbagi layar Android"
            textSize = 16f
            setTextColor(Color.rgb(238, 205, 205))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(20))
        }

        val scenery = TextView(this).apply {
            text = "☁       🐦        ☁\n\n        ☀\n\n  ⛰  ⛰   ⛰  ⛰\n"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 191, 128))
            setBackgroundColor(Color.rgb(95, 47, 75))
            setPadding(dp(12), dp(18), dp(12), dp(18))
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.rgb(43, 28, 48))
        }
        val panelTitle = TextView(this).apply {
            text = "SESI PERANGKAT INI"
            textSize = 14f
            setTextColor(Color.rgb(255, 157, 125))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }
        status = TextView(this).apply {
            text = "Status: belum berbagi layar"
            textSize = 16f
            setTextColor(Color.rgb(180, 255, 200))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(14))
        }
        val start = Button(this).apply {
            text = "Minta izin berbagi layar"
            setOnClickListener { requestScreenShare() }
        }
        val stop = Button(this).apply {
            text = "Hentikan sesi"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenShareService::class.java))
                status.text = "Status: sesi dihentikan"
                Toast.makeText(this@MainActivity, "Sesi dihentikan", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "Penting: versi ini meminta izin resmi Android untuk berbagi layar pada HP ini. Belum ada koneksi ke HP kedua atau kontrol sentuhan jarak jauh. Kode koneksi saja tidak memberi akses."
            textSize = 13f
            setTextColor(Color.rgb(226, 211, 222))
            setPadding(0, dp(16), 0, 0)
        }

        panel.addView(panelTitle)
        panel.addView(status)
        panel.addView(start)
        panel.addView(stop)
        panel.addView(note)

        root.addView(title)
        root.addView(subtitle)
        root.addView(scenery, LinearLayout.LayoutParams(-1, dp(160)).apply { bottomMargin = dp(18) })
        root.addView(panel, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
        }
    }

    private fun requestScreenShare() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated by Android; retained for compatibility with this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, ScreenShareService::class.java).apply {
                    putExtra("resultCode", resultCode)
                    putExtra("resultData", data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
                else startService(serviceIntent)
                status.text = "Status: izin diberikan; sesi aktif di HP ini"
                Toast.makeText(this, "Izin diberikan. Sesi lokal aktif.", Toast.LENGTH_LONG).show()
            } else {
                status.text = "Status: izin tidak diberikan"
            }
        }
    }
}
